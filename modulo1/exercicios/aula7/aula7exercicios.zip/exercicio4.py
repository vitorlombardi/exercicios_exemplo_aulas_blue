#- Crie um programa que tenha uma função chamada voto () que vai receber como parâmetro o ano de nascimento de uma pessoa, retornando um valor literal indicando se uma pessoa tem voto NEGADO, OPCIONAL ou OBRIGATORIO nas eleições. Para resolver esse exercício, pesquise sobre a função date da biblioteca Datetime.






from datetime import date

atual= (date.today().year)
ano=int(input('digite sua data de nascimento'))
def voto (atual,ano):
    if(atual-ano) < 16 :
      print('negado')
    elif (atual-ano ) >= 16 and (atual-ano) <18 or (atual-ano)>= 65:
         print('opcional')
    else:
      print('obrigatorio')