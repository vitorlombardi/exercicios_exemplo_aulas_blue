#Faça um programa que tenha uma função chamada ficha(), que receba dois parâmetros: o nome de um jogador e quantos gols ele marcou. O programa deverá ser capaz de mostrar a ficha do jogador, mesmo que algum dado não tenha sido informado corretamente.






def ficha  (nome, gol):
    print(nome , gol)


nome=input('digite o nome do jogador : ')
if len (nome) == 0:
  nome= 'sem cadastro'
gol=input('digite o numero de gols : ')
if gol.isnumeric():
    gol=int(gol)
else:
  gol='o'

ficha(nome, gol)


  




