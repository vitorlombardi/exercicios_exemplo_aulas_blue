#Escreva uma função que recebe dois parâmetros (números) e imprime o menor dos dois. Se eles forem iguais, imprima que são valores idênticos.

def numero (a,b):
    if (a < b):
        print (f"o numero menor e {a}")
    if ( a == b):
        print('os dois são iguais')




a=float(input('digite um numero : '))
b=float(input('digite um numero : '))

numero (a,b)