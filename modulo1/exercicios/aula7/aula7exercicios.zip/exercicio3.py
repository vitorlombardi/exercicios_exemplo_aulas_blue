#- Crie uma função que receba uma string como argumento e retorne a mesma string em letras maiúsculas. Faça uma chamada à função, passando como parâmetro uma string.

def palavra (frase):
    print(frase.upper())
    return
   
frase=input('digite uma palavra : ')

palavra(frase)

