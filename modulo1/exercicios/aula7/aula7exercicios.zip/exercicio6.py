#Um professor, muito legal, fez 3 provas durante um semestre, mas só vai levar em conta as duas notas mais altas para calcular a média.
#Faça uma aplicação que peça o valor das 3 notas, mostre como seria a média com essas 3 provas, a média com as 2 notas mais altas, bem como sua nota mais alta e sua nota mais baixa.




n1=float(input('qual a primeira nota : '))
n2=float(input('qual a segunda nota : '))
n3=float(input('qual a terceira nota : '))

print('a media com as três notas é : ', (n1+n2+n3)/3)



if (n1 > n2 and n1 > n3) and (n2 >= n3):
    print(f'média das duas notas mais altas: {(n1+n2)/2}') 
elif (n2 > n3 and n2 > n1) and (n1 >= n3):
  print(f'média das duas notas mais altas:{(n2+n1)/2} ')
elif (n3 > n2 and n3 > n1) and (n2 >= n1):
  print(f'média das duas notas mais altas: {(n3+n2)/2}')
elif (n1 > n3 and n1 > n2) and (n3 > n2):
  print(f'média das duas notas mais altas: {(n1+n3)/2}')
elif (n2 > n1 and n2 > n3) and (n1 >= n3):
  print(f'média das duas notas mais altas:{(n2+n1)/2}') 
elif (n3 > n2 and n3 > n1) and (n2 >= n1):
  print(f'média das duas notas mais altas:{(n3+n2)/2} ')
elif (n2 > n3 and n3 > n1) and (n3 >= n1):
  print(f'média das duas notas mais altas: {(n2+n3)/2}')
elif (n3 > n1 and n1 > n2) and (n1 > n2):
  print(f'média das duas notas mais altas: {(n3+n1)/2}')
  

print()

maior = n1

if n2 > maior:
  maior = n2
elif n3 > maior :
  maior = n3
   


print(f'a maior nota é : {maior}')



menor = n1

if n2 < menor:
  menor = n2
elif n3 < menor :
  menor = n3
   
print(f'a menor nota é : {menor}')





