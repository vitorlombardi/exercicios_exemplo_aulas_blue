#- Escreva uma função que recebe dois números (a e b) como parâmetro e retorna True caso a soma dos dois seja maior que um terceiro parâmetro, chamado limite.

def soma(a,b):
    if (a+b > limite):
      print('true')
    elif(a+b < limite):
      print('false')

limite = 10

a=float(input('digite um numero : '))
b=float(input('digite um numero : '))

soma(a,b)