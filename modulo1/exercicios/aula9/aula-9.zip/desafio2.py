#Faça um script que peça ao usuário o número de matérias da escola, ou seja, um inteiro positivo. Em seguida, ele vai digitando o valor de cada nota, de cada matéria e isso será armazenado numa lista. Ao final, seu script deverá fornecer a média geral do aluno.




ma = int(input('quantas materias você tem ? '))

notas = []

for cont in range (ma):
  notas = float(input(f'qul nota você tirou na {cont+1} materia ? '))
  notas.append(notas)


  print(f'{(sum(notas)/ma):.2f}')