#Elaborar um programa para imprimir os números de 1 (inclusive) até 10 (inclusive) em ordem decrescente. 



for cont in range (10,0,-1):
    print(cont)