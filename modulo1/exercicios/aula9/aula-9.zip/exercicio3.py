#Faça um programa que leia o estado civil de 15 pessoas (Solteiro / Casado) e mostre ao final a quantidade de pessoas de cada estado civil


sol = 0
cas =0


for cont in range(15):
    estado_cv = input('digite seu estdo civil (s= solteriro  c = casado)').upper()
    if estado_cv == 'S':
        sol = sol + 1

    else:
        cas = cas + 1

print('solteriro : {} , casado : {}'.format(sol,cas) )