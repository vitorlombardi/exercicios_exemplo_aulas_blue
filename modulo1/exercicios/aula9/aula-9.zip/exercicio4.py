#Faça um algoritmo que imprima 10 vezes a frase: “Go Blue”. 



frase = 'go blue'

for cont in range (10):
  print(frase)