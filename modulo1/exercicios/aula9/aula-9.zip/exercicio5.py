#. Faça um programa que mostre os valores numéricos inteiros ímpares situados na faixa de 0 a 20. 

for cont in range (1,21,2):
  print(cont)