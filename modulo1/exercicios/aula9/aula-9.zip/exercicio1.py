##Crie um código em Python que pede qual tabuada o usuário quer ver, em seguida imprima essa tabuada




a =int(input('digite um numero :'))

for cont in range (11):
    print('{} x {} = {}'.format(a,cont,a*cont))
