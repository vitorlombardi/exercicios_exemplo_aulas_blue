#. Faça um script em Python que exiba todos os possíveis palpites da Mega-Sena.
#Dados:
#Cada palpite possui 6 dezenas
#As dezenas variam de 1 até 60
#Não pode repetir dezena


possibilidades_totais = []
for n_1 in range(1,61):
    for n_2 in range(1, 61):
        for n_3 in range(1, 61):
            for n_4 in range(1, 61):
                for n_5 in range(1, 61):
                    for n_6 in range(1, 61):
              
              
              
                      possibilidades = [n_1, n_2, n_3, n_4, n_5, n_6]
                      possibilidades_totais.append(possibilidades)


print(possibilidades_totais)
print()
print(len(possibilidades_totais))


#não sei se ta certo ou funcionando por que quando fui testar o codigo meu pc morreu
