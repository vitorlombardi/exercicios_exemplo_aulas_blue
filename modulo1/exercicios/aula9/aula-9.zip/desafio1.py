#Escreva um programa que determine todos os números de 4 algarismos que possam ser separados em dois números de dois algarismos que somados e elevando-se a soma ao quadrado obtenha-se o próprio número.




for cont in range (1000,10000):
  p = cont // 100
  s = cont % 100

  resultado = p + s
  resultado = resultado ** 2

  if resultado == cont:
    print(f'{cont} : verdadeiro')