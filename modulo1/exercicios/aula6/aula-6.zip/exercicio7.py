#Escreva uma função que recebe dois parâmetros e imprime o menor dos dois. Se eles forem iguais, imprima que eles são iguais.





def menor (a,b):
  if (a<b):
      print(f'o menor valor é : {a}')
  elif (a>b):
      print(f'o menor valor é : {b}')
  elif (a==b):
      print('os dois valores são iguais' )

a=float(input('digite um valor : '))
b=float(input('digite outro valor : '))


menor(a,b)