#Faça um programa que calcule o salário de um colaborador na empresa XYZ. O salário é pago conforme a quantidade de horas trabalhadas. Quando um funcionário trabalha mais de 40 horas ele recebe um adicional de 1.5 nas horas extras trabalhadas.






def salario (horas):
    sa= (horas * valor_hora)
    if horas > 40:
      sa= sa + (valor_hora*1.5)
    return sa


valor_hora = 100

horas= float(input('digite quantas horas que o funcionario trabalhou : '))


print(f'esse mes o funcionario vai receber : {salario(horas)}')