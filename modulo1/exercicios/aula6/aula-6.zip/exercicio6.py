#Escreva uma função que, dado um número nota representando a nota de um estudante, converte o valor de nota para um conceito (A, B, C, D, E e F).




def nota (a):
    if (a <= 4.0):
        print('sua nota e F')
    elif (a >= 5.0 and a <= 6.9):
        print('sua nota é D')
    elif (a >= 7.0 and a <= 7.9 ):
        print('sua nota é C')
    elif (a >= 8.0 and a <= 8.9):
        print('sua nota é B')
    else:
        print('sua nota é A')



a = float(input('digite sua nota : ' ))

nota(a)