#Faça um programa que calcule através de uma função o IMC de uma pessoa que tenha 1,68 e pese 75kg(muidei o exercicio mesmo ,assim fica melhor)









def imc (peso,altura):
    IMC = peso/(altura*2)
    return IMC




peso = float (input('qual o seu peso : '))
altura =  float (input('qual a sua altura : '))

print(f'o seu IMC é {imc(peso,altura):.2f}')
