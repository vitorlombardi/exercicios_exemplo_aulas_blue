#Faça um programa, com uma função que necessite de três argumentos, e que forneça a soma desses três argumentos.


'''def soma (a,b,c):
    print('a soma é : ', a+b+c)
    
soma(1,5,3)

print()'''

def soma (a,b,c):
    print('a soma é : ', a+b+c)




p= float(input('digite um valor : '))
s= float(input('digite um valor : '))
t= float(input('digite um valor : '))

soma(p,s,t)