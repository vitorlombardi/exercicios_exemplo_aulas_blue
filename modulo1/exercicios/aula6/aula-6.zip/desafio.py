#DESAFIO -  Data com mês por extenso. Construa uma função que receba uma data no formato DD/MM/AAAA e devolva uma string no formato D de mesPorExtenso de AAAA. Opcionalmente, valide a data e retorne NULL caso a data seja inválida. Considere que Fevereiro tem 28 dias e que a cada 4 anos temos ano bisexto, sendo que nesses casos Fevereiro terá 29 dias.








data=(input('escreva uma data no formato: dia/mês/ano (em numeros)'))


def calendario(data):  

  dia=int(data[0:2])
  mes=int(data[3:5])
  ano=int(data[6:10])



  meses= ['','janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro']


  if (len(data)<10 or len(data)>10):
    print('erro...data invalida')
  elif (data[2]) != '/' or (data[5]) != '/':
    print('erro...digite a data com barra')
  elif (mes < 1 or mes > 12):
    print('erro...mês invalido')
  
  
  if(ano % 4 == 0 and ano % 100 != 100 or ano % 400 == 0):
    print(f'{dia} de {meses[mes]} de {ano} é uma data bisseta')

  else :
    print(f'{dia} de {meses[mes]} de {ano}')


calendario(data)



